/* Garrett Chan */

SELECT * FROM campuses;
SELECT COUNT(*) FROM campuses;
SELECT * FROM fees;
SELECT COUNT(*) FROM fees;
SELECT * FROM degrees;
SELECT COUNT(*) FROM degrees;
SELECT * FROM disciplines;
SELECT COUNT(*) FROM disciplines;
SELECT * FROM disciplineEnrollments;
SELECT COUNT(*) FROM disciplineEnrollments;
SELECT * FROM enrollments;
SELECT COUNT(*) FROM enrollments;
SELECT * FROM faculty;
SELECT COUNT(*) FROM faculty;