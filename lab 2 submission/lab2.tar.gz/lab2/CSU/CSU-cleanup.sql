/* Garrett Chan */

DROP TABLE campuses;
DROP TABLE fees;
DROP TABLE degrees;
DROP TABLE disciplines;
DROP TABLE disciplineEnrollments;
DROP TABLE enrollments;
DROP TABLE faculty;