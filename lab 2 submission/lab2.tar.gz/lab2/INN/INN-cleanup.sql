/* Garrett Chan */

DROP TABLE reservations;
DROP TABLE rooms;