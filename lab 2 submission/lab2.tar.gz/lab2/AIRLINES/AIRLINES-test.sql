/* Garrett Chan */

SELECT * FROM airlines;
SELECT COUNT(*) FROM airlines;
SELECT * FROM airports;
SELECT COUNT(*) FROM airports;
SELECT * FROM flights;
SELECT COUNT(*) FROM flights;