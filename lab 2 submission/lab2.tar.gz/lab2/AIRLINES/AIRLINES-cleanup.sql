/* Garrett Chan */

DROP TABLE airlines;
DROP TABLE airports;
DROP TABLE flights;