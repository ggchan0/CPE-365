/* Garrett Chan */
INSERT INTO band VALUES(1,'Solveig','Heilo');
INSERT INTO band VALUES(2,'Marianne','Sveen');
INSERT INTO band VALUES(3,'Anne-Marit','Bergheim');
INSERT INTO band VALUES(4,'Turid','Jorgensen');
