/* Garrett Chan */

DROP TABLE albums;
DROP TABLE band;
DROP TABLE instruments;
DROP TABLE performances;
DROP TABLE songs;
DROP TABLE tracklists;
DROP TABLE vocals;