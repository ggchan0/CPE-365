/* Garrett Chan */
SELECT * FROM marathon;
SELECT COUNT(*) FROM marathon;