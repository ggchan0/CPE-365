/* Garrett Chan */
DROP TABLE marathon;