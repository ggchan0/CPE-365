/* Garrett Chan */
DROP TABLE list;
DROP TABLE teachers;