-- ggchan
DROP TABLE appelations;
DROP TABLE grapes;
DROP TABLE wine;
