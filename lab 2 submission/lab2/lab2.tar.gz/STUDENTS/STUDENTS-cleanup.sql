-- ggchan
DROP TABLE list;
DROP TABLE teachers;