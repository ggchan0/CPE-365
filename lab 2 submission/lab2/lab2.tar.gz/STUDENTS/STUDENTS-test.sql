-- ggchan
SELECT * FROM list;
SELECT COUNT(*) FROM list;
SELECT * FROM teachers;
SELECT COUNT(*) FROM teachers;