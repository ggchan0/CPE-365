-- ggchan

DROP TABLE carMakers;
DROP TABLE carNames;
DROP TABLE carsData;
DROP TABLE continents;
DROP TABLE countries;
DROP TABLE modelList;