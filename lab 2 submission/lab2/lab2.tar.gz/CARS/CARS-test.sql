-- ggchan

SELECT * FROM carMakers;
SELECT COUNT(*) FROM carMakers;
SELECT * FROM carNames;
SELECT COUNT(*) FROM carNames;
SELECT * FROM carsData;
SELECT COUNT(*) FROM carsData;
SELECT * FROM continents;
SELECT COUNT(*) FROM continents;
SELECT * FROM countries;
SELECT COUNT(*) FROM countries;
SELECT * FROM modelList;
SELECT COUNT(*) FROM modelList;
