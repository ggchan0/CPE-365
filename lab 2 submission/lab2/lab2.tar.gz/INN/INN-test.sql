-- ggchan

SELECT * FROM reservations;
SELECT COUNT(*) FROM reservations;
SELECT * FROM rooms;
SELECT COUNT(*) FROM rooms;