-- ggchan

DROP TABLE reservations;
DROP TABLE rooms;