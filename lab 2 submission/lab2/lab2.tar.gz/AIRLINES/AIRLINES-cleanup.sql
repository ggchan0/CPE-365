-- ggchan

DROP TABLE airlines;
DROP TABLE airports;
DROP TABLE flights;