-- ggchan
SELECT * FROM marathon;
SELECT COUNT(*) FROM marathon;