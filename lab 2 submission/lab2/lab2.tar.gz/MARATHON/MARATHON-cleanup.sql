-- ggchan
DROP TABLE marathon;