-- ggchan

SELECT * FROM receipts;
SELECT COUNT(*) FROM receipts;
SELECT * FROM customers;
SELECT COUNT(*) FROM customers;
SELECT * FROM goods;
SELECT COUNT(*) FROM goods;
SELECT * from items;
SELECT COUNT(*) FROM items;
