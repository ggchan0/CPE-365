-- ggchan

DROP TABLE receipts;
DROP TABLE customers;
DROP TABLE goods;
DROP TABLE items;