
public class Teacher {

  public String lastName;
  public String firstName;
  public int classNumber;

  public Teacher(String lastName, String firstName, int classNumber) {
    this.lastName = lastName;
    this.firstName = firstName;
    this.classNumber = classNumber;
  }

}
